//
//  PushAlertViewProperties.h
//  didm_auth_sdk_iOS
//
//  Created by Mauricio Vivas on 10/19/16.
//  Copyright © 2016 appgate Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PushAlertViewProperties : NSObject

@property(nonatomic)NSString *APPROVE;

@end

