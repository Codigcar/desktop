//
//  UserAlreadyBlockedResponse.h
//  didm_auth_sdk_iOS
//
//  Created by Gerardo Tarazona on 12/5/18.
//  Copyright © 2018 appgate Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <didm_sdk/UserBlocked.h>

NS_ASSUME_NONNULL_BEGIN

@interface UserAlreadyBlockedResponse : UserBlocked

@end

NS_ASSUME_NONNULL_END
