//
//  didm_selfid_core.h
//  didm_selfid_core
//
//  Created by Elkin.Salcedo on 4/22/21.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

//! Project version number for didm_selfid_core.
FOUNDATION_EXPORT double didm_selfid_coreVersionNumber;

//! Project version string for didm_selfid_core.
FOUNDATION_EXPORT const unsigned char didm_selfid_coreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <didm_selfid_core/PublicHeader.h>

#import "DlibEasySolImpl.h"
#import "DataDetectionExceptionHandler.h"
