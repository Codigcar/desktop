//
//  didm_core.h
//  didm_core
//
//  Created by Elkin.Salcedo on 4/21/21.
//

#import <Foundation/Foundation.h>

//! Project version number for didm_core.
FOUNDATION_EXPORT double didm_coreVersionNumber;

//! Project version string for didm_core.
FOUNDATION_EXPORT const unsigned char didm_coreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <didm_core/PublicHeader.h>


